import os

with open('a.txt', 'wb') as f:
    f.write(os.urandom(((1024 ** 2) * 1) - 7))

with open('b.txt', 'wb') as f:
    f.write(os.urandom(((1024 ** 2) * 2) + 13))

with open('c.txt', 'wb') as f:
    f.write(os.urandom(((1024 ** 2) * 3) - 17))
    
